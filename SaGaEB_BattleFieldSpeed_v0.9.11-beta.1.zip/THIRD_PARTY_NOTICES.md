# 第三者の権利・依存・解析参考元

## ゲーム

『サガ エメラルド ビヨンド』のゲーム本体・キャラクター・データ・商標等は各権利者に帰属します。本MODは公式の提供・推奨を示すものではありません。ゲーム実行体、生成ゲームDLL、抽出bundle/CSV/JSON、ゲーム画像・音声はこの配布物へ同梱しません。

## 利用者の既存MelonLoader環境を使う依存

|プロジェクト|今回の参照環境|帰属・扱い|
|---|---|---|
|MelonLoader|0.7.0|Lava Gang。ローカル配布のライセンス文書はApache-2.0。既存環境を利用し、DLLは非同梱|
|HarmonyX / 0Harmony|2.10.2|BepInEx。公式v2.10.2のLICENSEはMIT。既存MelonLoader同梱版を参照、DLLは非同梱|
|Il2CppInterop.Runtime|1.4.6-ci.579|BepInEx / Il2CppInterop関連の権利者。公式masterのLICENSEにはLGPLv3/GPLv3本文がある。使用CIビルドの正確なrevision照合は未完了。DLLは非同梱|
|.NET / Unity|対象ゲーム・実行環境のもの|各権利者の条件に従う。ランタイム・ゲームDLLは非同梱|

HarmonyXの条件は [公式v2.10.2 LICENSE](https://github.com/BepInEx/HarmonyX/blob/v2.10.2/LICENSE) で確認しました。Il2CppInteropは [公式master LICENSE](https://github.com/BepInEx/Il2CppInterop/blob/master/LICENSE) を確認していますが、今回のCIビルドとの厳密なrevision対応は未完了です。非同梱だけを根拠にライセンス上の全対応が不要とは断定しません。公開前に使用版・動的参照・自作コードの利用条件との整合を確定してください。今回、依存DLLの改変・配布は行いません。

参考先：MelonLoader <https://github.com/LavaGang/MelonLoader>、HarmonyX <https://github.com/BepInEx/HarmonyX>、Il2CppInterop <https://github.com/BepInEx/Il2CppInterop>。

## 関連開発における解析参考データ

今回の配布は速度MODのみです。以下は関連するカシループ開発での参考元の記録であり、本ZIPにカシ自動化コード・抽出表・素材確率データを含めることを意味しません。既存の帰属とライセンス本文を保持しています。

niceandgoodonline / **SaGaEmeraldBeyondCSV**  
<https://github.com/niceandgoodonline/SaGaEmeraldBeyondCSV>  
照合に使用した固定コミット：`8c11951557b6e9df71ef642979232efe51eb562a`。

公開表はトレード解析の照合に利用しました。公開元のApache License 2.0本文を`LICENSES/SaGaEmeraldBeyondCSV-Apache-2.0.txt`へ保持します。公開表そのものやゲーム本体からの抽出表は同梱しません。この速度MODには、互換検証に必要なファイル名・ハッシュ等のみを残しています。

## 開発

本MODはCodexを利用して開発・検査しました。外部解析サイトへのファイル送信は、この公開準備では行っていません。自作コードの公開条件は`LICENSE_STATUS.md`を確認してください。
