# 0.9.11-beta.1

公開名：サガエメ 戦闘・移動高速化MOD  
English: SaGa Emerald Beyond – Battle & Field Speed

- 0.9.11-test.1を基準に、公開用の版表示を0.9.11-beta.1へ統一。
- DLLと内部名はEmeraldSafeQoLのまま維持。
- 速度処理、F10操作、倍率、OD移行保護、競合対策は変更なし。
- 日本語・英語README、設定見本、権利文書と製品DLLを配布ZIPへ整理。
- ソース・監査資料は導入用ZIPと分離。実機ログ、個人設定、セーブ、ゲーム本体・依存DLLは非同梱。

This beta repackages 0.9.11-test.1 with release version labels and documentation. It introduces no speed, control, or compatibility behavior changes. Known beta limitations are documented in the READMEs.
