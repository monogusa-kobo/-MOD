# SaGa Emerald Beyond – Battle & Field Speed

Japanese title: **サガエメ 戦闘・移動高速化MOD**  
Version: **0.9.11-beta.1**

MelonLoader and InformationalVersion use `0.9.11-beta.1`. Numeric .NET AssemblyVersion/FileVersion remain `0.9.11.0`; the base version was not incremented.

A MelonLoader beta mod for the Windows Steam version of *SaGa Emerald Beyond*. It speeds up battle presentation and field movement. The internal assembly and DLL names remain **EmeraldSafeQoL** and **EmeraldSafeQoL.dll**.

This package is based on 0.9.11-test.1 used in the user's game environment. Only release version labels and packaging/documentation were changed. Speed logic, controls, OD transition protection, and conflict handling are unchanged. The rebuilt beta DLL has not been launched in-game by the packager; full stability across all battles and events is not established.

## Controls

Press **F10** once to advance one speed step for the current context:

|Context|Action|
|---|---|
|Battle|Change battle speed, except during protected dialogs/fades|
|Normal world movement|Change world movement speed|
|Normal Junction movement|Change Junction movement speed|
|Trade screens|Do not change speed; compatible EmeraldKashiLab input takes priority|
|Menus, events, loading, or unknown control state|Do not change field speed|

- Battle starts at **2x**: **OFF (1x) → 1.5x → 2x → 3x → OFF**.
- World and Junction movement each start at **3x**: **3x → 1.5x → 2x → OFF (1x) → 3x**.
- The three settings are independent. They return to the startup defaults on the next game launch.
- A speed notification appears at the upper left for about 2.5 seconds after a change.
- L3/R3 are not used to change mod speed.
- Battle command input remains at normal speed. The dedicated OD transition temporarily uses normal speed; subsequent attacks use the latest selected setting.
- Supported Sank and Mare Nostrum boats use the world movement setting.

Field movement rechecks the selected multiplier when normal control resumes, using the game's current input/menu/event state and the current movement target. A displayed multiplier represents the selected setting, not a guarantee that every animation or post-collision movement runs at that exact rate.

## Requirements

- Windows Steam edition of *SaGa Emerald Beyond*.
- Reference environment: **MelonLoader 0.7.0 / .NET 6 / IL2CPP**.
- Supported GameAssembly SHA256: `E3E9294A9FCD1EBE32DDA362FE7619FB6E6EF4ADFD755956C147CFDE213E667F`.

The mod checks the game binary, generated assemblies, and hook signatures. Other game builds or generated wrappers may be rejected. Do not bypass compatibility checks. Game files, MelonLoader, and dependency DLLs are not included.

## Installation or update

1. Exit the game and keep a backup of your current mod DLL and configuration.
2. Move the old `EmeraldSafeQoL.dll` outside the game's `Mods` directory. Do not load multiple versions, old observation builds, or old motion test builds together.
3. Copy this package's `Mods/EmeraldSafeQoL.dll` into the game's `Mods` directory.
4. Keep an existing configuration if you have one. If needed, copy `Config/EmeraldSafeQoL.cfg.example` to `UserData/EmeraldSafeQoL/EmeraldSafeQoL.cfg`, removing the `.example` suffix.

Use `DebugLog=false` for normal play. The legacy `GamepadShortcuts` key does not restore L3/R3 speed controls. Some configuration keys are retained for compatibility; this DLL does not provide Kashi trade automation.

## Compatibility

EmeraldKashiLab versions implementing the shared F10 v1 contract coordinate trade/battle/movement input without another shared DLL. Older versions or unrelated F10 mods are untested.

The existing conflict handling recognizes a verified EmeraldBeyondQoL v1.0 build and suppresses five identified speed writes after fingerprint/signature checks. It does not replace the DLL or its entire OnUpdate. Unknown versions or additional patches are unsupported.

## Known beta limitations

- Battle input can become unresponsive in some reported situations while background animation and audio continue. The cause is unresolved. Freezes were previously reported at 3x; the 2x startup setting is retained. This beta does not claim to resolve every freeze.
- Full field recovery across every event, battle, and menu sequence remains under verification. If F10 or movement speed stops working, record the scene and the preceding transition.
- **No automatic quicksand protection is provided.** Select movement OFF (1x) before entering quicksand or special moving floors. OFF may also help with precise tile selection in Avalon.
- Unknown special vehicles, the Delta Base lift, Miyako trains, and additional long boss-introduction skips are unsupported.
- Multi-hit timing and battle timeline/reserve display synchronization have unresolved issues.

This mod does not provide direct save, trial, inventory, or character ability editing.

## Diagnostics and removal

For a short diagnostic session, enable `DebugLog=true`. Bounded `起動_*.jsonl` and `移動_*.jsonl` logs are written under `UserData/EmeraldSafeQoL`. Remove usernames and absolute paths before sharing logs. No gameplay logs are included in this distribution.

To uninstall, exit the game and remove `Mods/EmeraldSafeQoL.dll`. Restore a backed-up DLL to roll back. You do not need to delete game saves.

This is an unofficial mod and is not endorsed by Square Enix. Codex was used during development and verification. See `LICENSE_STATUS.md`, `THIRD_PARTY_NOTICES.md`, and `LICENSES` for usage terms and third-party notices.
